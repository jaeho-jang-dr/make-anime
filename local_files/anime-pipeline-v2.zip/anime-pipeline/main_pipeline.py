#!/usr/bin/env python3
"""
=============================================================================
🎬 AI 애니메이션 파이프라인 - 메인 실행기
=============================================================================
Google Antigravity + Claude CLI + Gemini + Grok + Whisk 통합 워크플로우

【지원 환경】
1. Claude in Chrome: 브라우저로 Whisk 직접 자동화
2. Antigravity + Claude CLI: Luma API 또는 수동 Whisk 가이드

사용법:
    # 환경 자동 감지
    python main_pipeline.py --mode full
    
    # 브라우저 모드 (Claude in Chrome)
    python main_pipeline.py --mode full --backend browser
    
    # API 모드 (Antigravity - Luma API 사용)
    python main_pipeline.py --mode full --backend luma
    
    # 수동 모드 (가이드만 출력)
    python main_pipeline.py --mode full --backend manual
    
    # 개별 단계
    python main_pipeline.py --mode script    # 스크립트만 생성
    python main_pipeline.py --mode images    # 이미지 프롬프트만
    python main_pipeline.py --mode video     # 영상 생성 (Whisk/Luma)
    python main_pipeline.py --mode audio     # 오디오만
    python main_pipeline.py --mode render    # 렌더링만
"""

import os
import sys
import json
import argparse
from pathlib import Path
from datetime import datetime

# 프로젝트 경로 설정
PROJECT_DIR = Path("/home/claude/anime-pipeline")
SCRIPTS_DIR = PROJECT_DIR / "scripts"

# 모듈 임포트
sys.path.insert(0, str(SCRIPTS_DIR))

try:
    from step1_script_generator import ScriptGenerator, SAMPLE_SCRIPT
    from step2_image_generator import process_script_for_images, GeminiImageGenerator
    from step2b_video_generator import UnifiedVideoGenerator, VideoGenerationRequest
    from step3_audio_generator import process_script_for_audio
    from step4_render_final import ProjectAssembler
    from whisk_automation_workflow import WhiskAutomationWorkflow, create_claude_prompt_for_whisk
except ImportError as e:
    print(f"⚠️ 모듈 임포트 오류: {e}")
    print("개별 스크립트를 직접 실행하세요.")


class AnimePipeline:
    """AI 애니메이션 제작 통합 파이프라인"""
    
    def __init__(self, project_dir: str = None, backend: str = "auto"):
        """
        Args:
            project_dir: 프로젝트 디렉토리
            backend: "browser" | "luma" | "kling" | "manual" | "auto"
        """
        self.project_dir = Path(project_dir) if project_dir else PROJECT_DIR
        self.backend = backend
        self.setup_directories()
        
        # 설정 로드
        self.config = self.load_config()
        
    def setup_directories(self):
        """디렉토리 구조 생성"""
        directories = [
            "scripts",
            "characters", 
            "scenes/clips",
            "scenes/backgrounds",
            "audio/voice",
            "audio/bgm",
            "audio/sfx",
            "output",
            "config"
        ]
        
        for dir_name in directories:
            (self.project_dir / dir_name).mkdir(parents=True, exist_ok=True)
    
    def load_config(self) -> dict:
        """설정 파일 로드"""
        config_path = self.project_dir / "config" / "pipeline_config.json"
        
        if config_path.exists():
            with open(config_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        
        return {
            "project": {"name": "AI Anime", "target_duration_minutes": 10},
            "whisk_settings": {"monthly_limit": 100, "clip_length": 8}
        }
    
    def run_step1_script(self, 
                         genre: str = "판타지",
                         duration: int = 10,
                         theme: str = "모험과 성장",
                         use_sample: bool = True) -> str:
        """Step 1: 스크립트 생성"""
        
        print("\n" + "=" * 70)
        print("📖 STEP 1: 스토리 & 스크립트 생성")
        print("=" * 70)
        
        generator = ScriptGenerator(output_dir=str(self.project_dir / "scripts"))
        
        if use_sample:
            print("📌 샘플 스크립트 사용 (Claude CLI 없이 테스트)")
            script_path = generator.save_script(SAMPLE_SCRIPT, "anime_script.json")
        else:
            print(f"📌 Claude CLI로 새 스크립트 생성 중...")
            print(f"   장르: {genre}, 길이: {duration}분, 테마: {theme}")
            
            script = generator.generate_full_script(
                genre=genre,
                duration_minutes=duration,
                theme=theme
            )
            script_path = generator.save_script(script, "anime_script.json")
        
        print(f"\n✅ 스크립트 저장됨: {script_path}")
        return str(script_path)
    
    def run_step2_images(self, script_path: str) -> dict:
        """Step 2: 이미지 프롬프트 생성"""
        
        print("\n" + "=" * 70)
        print("🎨 STEP 2: 캐릭터 & 장면 이미지 준비")
        print("=" * 70)
        
        result = process_script_for_images(script_path, str(self.project_dir))
        
        print(f"\n✅ 이미지 프롬프트 준비 완료")
        print(f"   - 캐릭터: {len(result['character_images'])}개")
        print(f"   - Whisk 장면: {len(result['whisk_scenes'])}개")
        
        return result
    
    def run_step2b_video(self, script_path: str) -> dict:
        """Step 2B: 이미지→영상 변환 (Whisk 또는 Luma API)"""
        
        print("\n" + "=" * 70)
        print("🎥 STEP 2B: 영상 클립 생성")
        print("=" * 70)
        
        results = {"clips": [], "mode": self.backend}
        
        if self.backend == "browser":
            # Claude in Chrome 모드: 워크플로우 지시사항 생성
            print("📌 모드: Claude in Chrome (브라우저 자동화)")
            print("   Whisk 자동화 워크플로우를 생성합니다.")
            
            workflow = WhiskAutomationWorkflow(str(self.project_dir))
            
            with open(script_path, 'r', encoding='utf-8') as f:
                script = json.load(f)
            
            scenes = script.get("scenes", [])
            
            # 배치 워크플로우 생성
            batch_workflow = workflow.generate_batch_workflow(1, len(scenes))
            
            workflow_path = self.project_dir / "WHISK_BROWSER_WORKFLOW.txt"
            with open(workflow_path, 'w', encoding='utf-8') as f:
                f.write(batch_workflow)
            
            print(f"\n   ✓ 워크플로우 저장됨: {workflow_path}")
            print("\n" + "─" * 50)
            print("📋 Claude in Chrome에서 다음 명령을 실행하세요:")
            print("─" * 50)
            print(f'\n   "WHISK_BROWSER_WORKFLOW.txt를 읽고 Whisk에서')
            print(f'    장면 1부터 영상을 생성해줘"')
            print("\n" + "─" * 50)
            
            results["workflow_path"] = str(workflow_path)
            results["mode"] = "browser"
            
        elif self.backend in ["luma", "kling", "auto"]:
            # API 모드: 자동 생성
            print(f"📌 모드: API 자동화 ({self.backend})")
            
            generator = UnifiedVideoGenerator(
                mode=self.backend,
                output_dir=str(self.project_dir / "scenes" / "clips")
            )
            
            clip_results = generator.generate_all_scenes(script_path)
            results["clips"] = clip_results
            results["success_count"] = sum(1 for r in clip_results if r.success)
            
        else:  # manual
            # 수동 모드: 가이드만 출력
            print("📌 모드: 수동 (가이드 출력)")
            print("   Whisk 작업 가이드를 참조하세요:")
            print(f"   {self.project_dir / 'WHISK_WORKFLOW_GUIDE.txt'}")
            
            results["mode"] = "manual"
        
        return results
    
    def run_step3_audio(self, script_path: str) -> dict:
        """Step 3: 오디오 생성"""
        
        print("\n" + "=" * 70)
        print("🎵 STEP 3: 오디오 생성")
        print("=" * 70)
        
        result = process_script_for_audio(script_path, str(self.project_dir))
        
        print(f"\n✅ 오디오 준비 완료")
        print(f"   - 음성 클립: {result['total_clips']}개")
        
        return result
    
    def run_step4_render(self, script_path: str, bgm_path: str = None) -> str:
        """Step 4: 최종 렌더링"""
        
        print("\n" + "=" * 70)
        print("🎬 STEP 4: 최종 렌더링")
        print("=" * 70)
        
        assembler = ProjectAssembler(str(self.project_dir))
        clips_dir = str(self.project_dir / "scenes" / "clips")
        
        result = assembler.full_assembly(script_path, clips_dir, bgm_path)
        
        if result:
            print(f"\n✅ 최종 영상: {result}")
        else:
            # 가이드 출력
            guide = assembler.generate_assembly_guide(script_path)
            print(guide)
        
        return result
    
    def run_full_pipeline(self,
                          genre: str = "판타지",
                          duration: int = 10,
                          theme: str = "모험과 성장",
                          use_sample: bool = True) -> dict:
        """전체 파이프라인 실행"""
        
        print("\n" + "█" * 70)
        print("█" + " " * 68 + "█")
        print("█" + "    🎬 AI 애니메이션 파이프라인 시작".center(66) + "█")
        print("█" + f"    백엔드: {self.backend}".center(66) + "█")
        print("█" + " " * 68 + "█")
        print("█" * 70)
        
        start_time = datetime.now()
        results = {}
        
        # Step 1: 스크립트
        script_path = self.run_step1_script(genre, duration, theme, use_sample)
        results["script_path"] = script_path
        
        # Step 2: 이미지 프롬프트
        image_result = self.run_step2_images(script_path)
        results["images"] = image_result
        
        # Step 2B: 영상 생성 (백엔드에 따라 다름)
        video_result = self.run_step2b_video(script_path)
        results["video"] = video_result
        
        # Step 3: 오디오
        audio_result = self.run_step3_audio(script_path)
        results["audio"] = audio_result
        
        # Step 4: 렌더링 안내
        if self.backend == "browser":
            print("\n" + "=" * 70)
            print("⏸️  다음 단계: Claude in Chrome에서 Whisk 자동화 실행")
            print("=" * 70)
            print(f"""
1. Claude in Chrome에서:
   "WHISK_BROWSER_WORKFLOW.txt를 읽고 Whisk에서 영상 생성해줘"

2. 영상 생성 완료 후:
   python main_pipeline.py --mode render
""")
        elif self.backend in ["luma", "kling"]:
            if video_result.get("success_count", 0) > 0:
                print("\n" + "=" * 70)
                print("🎬 자동 렌더링 진행")
                print("=" * 70)
                final = self.run_step4_render(script_path)
                results["final"] = final
        else:
            print("\n" + "=" * 70)
            print("⏸️  수동 작업 필요")
            print("=" * 70)
            print(f"""
1. Whisk에서 수동으로 영상 생성:
   {self.project_dir / 'WHISK_WORKFLOW_GUIDE.txt'} 참조

2. 클립 저장:
   {self.project_dir / 'scenes' / 'clips'}/

3. 렌더링:
   python main_pipeline.py --mode render
""")
        
        # 완료
        elapsed = datetime.now() - start_time
        print("\n" + "█" * 70)
        print(f"⏱️  파이프라인 완료 (소요: {elapsed.seconds}초)")
        print("█" * 70)
        
        return results
    
    def print_project_status(self):
        """프로젝트 상태 출력"""
        
        print("\n" + "=" * 70)
        print("📊 프로젝트 상태")
        print("=" * 70)
        
        # 스크립트 확인
        script_path = self.project_dir / "scripts" / "anime_script.json"
        if script_path.exists():
            with open(script_path, 'r', encoding='utf-8') as f:
                script = json.load(f)
            print(f"✅ 스크립트: {script.get('title', 'N/A')}")
            print(f"   - 장면 수: {len(script.get('scenes', []))}")
            print(f"   - 캐릭터 수: {len(script.get('characters', []))}")
        else:
            print("❌ 스크립트: 없음")
        
        # 클립 확인
        clips_dir = self.project_dir / "scenes" / "clips"
        clips = list(clips_dir.glob("*.mp4")) if clips_dir.exists() else []
        print(f"\n📹 비디오 클립: {len(clips)}개")
        
        # 오디오 확인
        audio_dir = self.project_dir / "audio"
        audio_files = list(audio_dir.glob("**/*.mp3")) if audio_dir.exists() else []
        print(f"🔊 오디오 파일: {len(audio_files)}개")
        
        # 출력 확인
        output_dir = self.project_dir / "output"
        outputs = list(output_dir.glob("*.mp4")) if output_dir.exists() else []
        print(f"🎬 최종 출력: {len(outputs)}개")
        
        print("\n" + "=" * 70)


def main():
    """메인 함수"""
    
    parser = argparse.ArgumentParser(
        description="🎬 AI 애니메이션 파이프라인",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
예시:
  # 환경 자동 감지 (Luma API 있으면 사용, 없으면 수동)
  python main_pipeline.py --mode full
  
  # Claude in Chrome 브라우저 자동화
  python main_pipeline.py --mode full --backend browser
  
  # Luma API 사용 (완전 자동)
  python main_pipeline.py --mode full --backend luma
  
  # 수동 모드 (가이드만)
  python main_pipeline.py --mode full --backend manual
  
  # 개별 단계
  python main_pipeline.py --mode script         # 스크립트 생성
  python main_pipeline.py --mode video          # 영상 생성
  python main_pipeline.py --mode render         # 렌더링
  
  # 커스텀 스크립트 생성 (Claude CLI 필요)
  python main_pipeline.py --mode script --genre SF --duration 5 --no-sample
        """
    )
    
    parser.add_argument("--mode", 
                        choices=["full", "script", "images", "video", "audio", "render", "status", "guide"],
                        default="status",
                        help="실행 모드")
    parser.add_argument("--backend",
                        choices=["browser", "luma", "kling", "manual", "auto"],
                        default="auto",
                        help="영상 생성 백엔드")
    parser.add_argument("--genre", default="판타지", help="장르")
    parser.add_argument("--duration", type=int, default=10, help="길이(분)")
    parser.add_argument("--theme", default="모험과 성장", help="테마")
    parser.add_argument("--no-sample", action="store_true", help="샘플 대신 새로 생성")
    parser.add_argument("--bgm", default=None, help="BGM 파일 경로")
    parser.add_argument("--scene", type=int, help="특정 장면 번호 (video 모드)")
    
    args = parser.parse_args()
    
    pipeline = AnimePipeline(backend=args.backend)
    script_path = str(pipeline.project_dir / "scripts" / "anime_script.json")
    
    # 샘플 스크립트 경로도 확인
    sample_script_path = str(pipeline.project_dir / "scripts" / "sample_script.json")
    if not Path(script_path).exists() and Path(sample_script_path).exists():
        script_path = sample_script_path
    
    if args.mode == "status":
        pipeline.print_project_status()
    
    elif args.mode == "full":
        pipeline.run_full_pipeline(
            genre=args.genre,
            duration=args.duration,
            theme=args.theme,
            use_sample=not args.no_sample
        )
    
    elif args.mode == "script":
        pipeline.run_step1_script(
            genre=args.genre,
            duration=args.duration,
            theme=args.theme,
            use_sample=not args.no_sample
        )
    
    elif args.mode == "images":
        if Path(script_path).exists():
            pipeline.run_step2_images(script_path)
        else:
            print("❌ 먼저 스크립트를 생성하세요: --mode script")
    
    elif args.mode == "video":
        if Path(script_path).exists():
            pipeline.run_step2b_video(script_path)
        else:
            print("❌ 먼저 스크립트를 생성하세요: --mode script")
    
    elif args.mode == "audio":
        if Path(script_path).exists():
            pipeline.run_step3_audio(script_path)
        else:
            print("❌ 먼저 스크립트를 생성하세요: --mode script")
    
    elif args.mode == "render":
        if Path(script_path).exists():
            pipeline.run_step4_render(script_path, args.bgm)
        else:
            print("❌ 먼저 스크립트를 생성하세요: --mode script")
    
    elif args.mode == "guide":
        assembler = ProjectAssembler()
        if Path(script_path).exists():
            guide = assembler.generate_assembly_guide(script_path)
            print(guide)
        else:
            print("❌ 먼저 스크립트를 생성하세요: --mode script")


if __name__ == "__main__":
    main()
