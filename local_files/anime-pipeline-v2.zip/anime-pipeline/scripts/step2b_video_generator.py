#!/usr/bin/env python3
"""
=============================================================================
STEP 2B: 이미지→영상 변환 (Whisk 브라우저 자동화 + Luma API 대체)
=============================================================================

두 가지 모드 지원:
1. BROWSER 모드: Claude in Chrome으로 Whisk 자동 조작
2. API 모드: Luma Dream Machine API로 자동 생성 (Antigravity용)

사용법:
    # 브라우저 모드 (Claude in Chrome 환경)
    python step2b_video_generator.py --mode browser --scene 1
    
    # API 모드 (Antigravity / Claude CLI 환경)  
    python step2b_video_generator.py --mode api --scene 1
    
    # 전체 장면 처리
    python step2b_video_generator.py --mode api --all
"""

import os
import sys
import json
import time
import base64
import requests
from pathlib import Path
from typing import Optional, Dict, List, Any
from dataclasses import dataclass
from abc import ABC, abstractmethod


@dataclass
class VideoGenerationRequest:
    """영상 생성 요청"""
    scene_number: int
    image_path: Optional[str]  # 이미지 파일 경로
    image_prompt: str          # 이미지 생성 프롬프트 (이미지 없을 때)
    animation_prompt: str      # 애니메이션 동작 프롬프트
    duration_seconds: int = 8
    style_reference: Optional[str] = None


@dataclass  
class VideoGenerationResult:
    """영상 생성 결과"""
    scene_number: int
    success: bool
    video_path: Optional[str]
    error_message: Optional[str] = None
    generation_time_seconds: float = 0


class VideoGeneratorBase(ABC):
    """영상 생성기 기본 클래스"""
    
    @abstractmethod
    def generate_video(self, request: VideoGenerationRequest) -> VideoGenerationResult:
        pass
    
    @abstractmethod
    def check_availability(self) -> bool:
        pass


# =============================================================================
# Mode 1: Whisk 브라우저 자동화 (Claude in Chrome용)
# =============================================================================

class WhiskBrowserAutomation(VideoGeneratorBase):
    """
    Whisk 브라우저 자동화
    
    이 클래스는 Claude in Chrome 환경에서 실행됩니다.
    실제 브라우저 조작은 Claude가 MCP 도구로 수행합니다.
    """
    
    WHISK_URL = "https://labs.google/fx/tools/whisk"
    
    def __init__(self, output_dir: str = "scenes/clips"):
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        
    def check_availability(self) -> bool:
        """Claude in Chrome 환경 확인"""
        # 이 메서드는 실제로 Claude가 브라우저 도구 사용 가능 여부로 판단
        return True  # Claude in Chrome에서 호출 시 True
    
    def generate_browser_instructions(self, request: VideoGenerationRequest) -> Dict[str, Any]:
        """
        Claude in Chrome이 실행할 브라우저 명령어 생성
        
        Returns:
            Claude가 실행할 단계별 지시사항
        """
        
        instructions = {
            "scene_number": request.scene_number,
            "url": self.WHISK_URL,
            "steps": [
                {
                    "action": "navigate",
                    "target": self.WHISK_URL,
                    "description": "Whisk 페이지 접속"
                },
                {
                    "action": "wait",
                    "duration": 3,
                    "description": "페이지 로딩 대기"
                },
                {
                    "action": "find_and_click",
                    "target": "Subject 입력 영역",
                    "description": "Subject 섹션 찾기"
                },
                {
                    "action": "input_text",
                    "target": "Subject prompt",
                    "value": request.image_prompt,
                    "description": "캐릭터/주제 프롬프트 입력"
                },
                {
                    "action": "find_and_click",
                    "target": "Scene 입력 영역", 
                    "description": "Scene 섹션 찾기"
                },
                {
                    "action": "input_text",
                    "target": "Scene prompt",
                    "value": f"anime background, {request.animation_prompt.split(',')[0]}",
                    "description": "배경 프롬프트 입력"
                },
                {
                    "action": "click",
                    "target": "Create 버튼",
                    "description": "이미지 생성 시작"
                },
                {
                    "action": "wait_for_generation",
                    "timeout": 60,
                    "description": "이미지 생성 완료 대기"
                },
                {
                    "action": "click",
                    "target": "ANIMATE 버튼",
                    "description": "애니메이션 모드 전환"
                },
                {
                    "action": "input_text",
                    "target": "Animation prompt",
                    "value": request.animation_prompt,
                    "description": "애니메이션 프롬프트 입력"
                },
                {
                    "action": "click",
                    "target": "Generate 버튼",
                    "description": "영상 생성 시작"
                },
                {
                    "action": "wait_for_generation",
                    "timeout": 120,
                    "description": "영상 생성 완료 대기 (최대 2분)"
                },
                {
                    "action": "download",
                    "target": "생성된 영상",
                    "filename": f"scene_{request.scene_number:03d}.mp4",
                    "description": "영상 다운로드"
                }
            ],
            "output_filename": f"scene_{request.scene_number:03d}.mp4",
            "output_dir": str(self.output_dir)
        }
        
        return instructions
    
    def generate_video(self, request: VideoGenerationRequest) -> VideoGenerationResult:
        """
        브라우저 자동화로 영상 생성
        
        Note: 실제 실행은 Claude in Chrome이 수행
        이 메서드는 지시사항만 생성
        """
        instructions = self.generate_browser_instructions(request)
        
        # 지시사항을 JSON으로 저장 (Claude가 읽어서 실행)
        instructions_path = self.output_dir / f"whisk_instructions_{request.scene_number:03d}.json"
        with open(instructions_path, 'w', encoding='utf-8') as f:
            json.dump(instructions, f, indent=2, ensure_ascii=False)
        
        return VideoGenerationResult(
            scene_number=request.scene_number,
            success=True,
            video_path=str(instructions_path),
            error_message="브라우저 지시사항 생성됨 - Claude in Chrome에서 실행 필요"
        )


# =============================================================================
# Mode 2: Luma Dream Machine API (Antigravity / CLI용)
# =============================================================================

class LumaAPIGenerator(VideoGeneratorBase):
    """
    Luma Dream Machine API를 사용한 영상 생성
    Antigravity + Claude CLI 환경에서 완전 자동화 가능
    """
    
    API_BASE = "https://api.lumalabs.ai/dream-machine/v1"
    
    def __init__(self, api_key: Optional[str] = None, output_dir: str = "scenes/clips"):
        self.api_key = api_key or os.environ.get("LUMA_API_KEY")
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        
    def check_availability(self) -> bool:
        """API 키 확인"""
        return bool(self.api_key)
    
    def _get_headers(self) -> Dict[str, str]:
        return {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        }
    
    def generate_video(self, request: VideoGenerationRequest) -> VideoGenerationResult:
        """Luma API로 영상 생성"""
        
        if not self.check_availability():
            return VideoGenerationResult(
                scene_number=request.scene_number,
                success=False,
                video_path=None,
                error_message="LUMA_API_KEY 환경변수가 설정되지 않음"
            )
        
        start_time = time.time()
        
        try:
            # 1. 이미지가 있으면 이미지→영상, 없으면 텍스트→영상
            if request.image_path and Path(request.image_path).exists():
                generation_id = self._create_image_to_video(request)
            else:
                generation_id = self._create_text_to_video(request)
            
            if not generation_id:
                return VideoGenerationResult(
                    scene_number=request.scene_number,
                    success=False,
                    video_path=None,
                    error_message="영상 생성 요청 실패"
                )
            
            # 2. 생성 완료 대기
            video_url = self._wait_for_completion(generation_id)
            
            if not video_url:
                return VideoGenerationResult(
                    scene_number=request.scene_number,
                    success=False,
                    video_path=None,
                    error_message="영상 생성 타임아웃"
                )
            
            # 3. 영상 다운로드
            output_path = self.output_dir / f"scene_{request.scene_number:03d}.mp4"
            self._download_video(video_url, output_path)
            
            elapsed = time.time() - start_time
            
            return VideoGenerationResult(
                scene_number=request.scene_number,
                success=True,
                video_path=str(output_path),
                generation_time_seconds=elapsed
            )
            
        except Exception as e:
            return VideoGenerationResult(
                scene_number=request.scene_number,
                success=False,
                video_path=None,
                error_message=str(e)
            )
    
    def _create_text_to_video(self, request: VideoGenerationRequest) -> Optional[str]:
        """텍스트→영상 생성 요청"""
        
        prompt = f"{request.image_prompt}, {request.animation_prompt}, anime style, high quality animation"
        
        payload = {
            "prompt": prompt,
            "aspect_ratio": "16:9",
            "loop": False
        }
        
        try:
            response = requests.post(
                f"{self.API_BASE}/generations",
                headers=self._get_headers(),
                json=payload,
                timeout=30
            )
            
            if response.status_code == 201:
                data = response.json()
                return data.get("id")
            else:
                print(f"   API 오류: {response.status_code} - {response.text}")
                return None
                
        except Exception as e:
            print(f"   요청 오류: {e}")
            return None
    
    def _create_image_to_video(self, request: VideoGenerationRequest) -> Optional[str]:
        """이미지→영상 생성 요청"""
        
        # 이미지를 base64로 인코딩
        with open(request.image_path, 'rb') as f:
            image_data = base64.b64encode(f.read()).decode('utf-8')
        
        # 먼저 이미지 업로드
        # (Luma API 구조에 따라 다를 수 있음)
        
        payload = {
            "prompt": request.animation_prompt,
            "keyframes": {
                "frame0": {
                    "type": "image",
                    "url": f"data:image/png;base64,{image_data}"
                }
            },
            "aspect_ratio": "16:9",
            "loop": False
        }
        
        try:
            response = requests.post(
                f"{self.API_BASE}/generations",
                headers=self._get_headers(),
                json=payload,
                timeout=30
            )
            
            if response.status_code == 201:
                return response.json().get("id")
            return None
            
        except Exception as e:
            print(f"   요청 오류: {e}")
            return None
    
    def _wait_for_completion(self, generation_id: str, timeout: int = 300) -> Optional[str]:
        """생성 완료 대기"""
        
        start_time = time.time()
        
        while time.time() - start_time < timeout:
            try:
                response = requests.get(
                    f"{self.API_BASE}/generations/{generation_id}",
                    headers=self._get_headers(),
                    timeout=10
                )
                
                if response.status_code == 200:
                    data = response.json()
                    state = data.get("state")
                    
                    if state == "completed":
                        assets = data.get("assets", {})
                        return assets.get("video")
                    elif state == "failed":
                        print(f"   생성 실패: {data.get('failure_reason')}")
                        return None
                    
                    # 진행 중
                    print(f"   생성 중... ({state})")
                
            except Exception as e:
                print(f"   상태 확인 오류: {e}")
            
            time.sleep(10)  # 10초마다 확인
        
        return None  # 타임아웃
    
    def _download_video(self, url: str, output_path: Path):
        """영상 다운로드"""
        
        response = requests.get(url, stream=True, timeout=60)
        
        with open(output_path, 'wb') as f:
            for chunk in response.iter_content(chunk_size=8192):
                f.write(chunk)
        
        print(f"   ✓ 다운로드 완료: {output_path}")


# =============================================================================
# Mode 3: Kling AI API (대안)
# =============================================================================

class KlingAPIGenerator(VideoGeneratorBase):
    """
    Kling AI API를 사용한 영상 생성
    월 $5.99부터 사용 가능
    """
    
    API_BASE = "https://api.klingai.com/v1"
    
    def __init__(self, api_key: Optional[str] = None, output_dir: str = "scenes/clips"):
        self.api_key = api_key or os.environ.get("KLING_API_KEY")
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
    
    def check_availability(self) -> bool:
        return bool(self.api_key)
    
    def generate_video(self, request: VideoGenerationRequest) -> VideoGenerationResult:
        """Kling API로 영상 생성 (구현 예시)"""
        
        if not self.check_availability():
            return VideoGenerationResult(
                scene_number=request.scene_number,
                success=False,
                video_path=None,
                error_message="KLING_API_KEY 환경변수가 설정되지 않음"
            )
        
        # Kling API 호출 로직
        # (실제 API 문서에 따라 구현)
        
        return VideoGenerationResult(
            scene_number=request.scene_number,
            success=False,
            video_path=None,
            error_message="Kling API 구현 필요"
        )


# =============================================================================
# 통합 비디오 생성기
# =============================================================================

class UnifiedVideoGenerator:
    """
    통합 비디오 생성기
    환경에 따라 적절한 백엔드 자동 선택
    """
    
    def __init__(self, 
                 mode: str = "auto",
                 output_dir: str = "scenes/clips"):
        """
        Args:
            mode: "browser" | "luma" | "kling" | "auto"
            output_dir: 출력 디렉토리
        """
        self.mode = mode
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        
        # 백엔드 초기화
        self.backends = {
            "browser": WhiskBrowserAutomation(str(self.output_dir)),
            "luma": LumaAPIGenerator(output_dir=str(self.output_dir)),
            "kling": KlingAPIGenerator(output_dir=str(self.output_dir))
        }
        
        # 자동 모드: 사용 가능한 백엔드 선택
        if mode == "auto":
            self.active_backend = self._select_backend()
        else:
            self.active_backend = self.backends.get(mode)
    
    def _select_backend(self) -> VideoGeneratorBase:
        """사용 가능한 백엔드 자동 선택"""
        
        # 1. Luma API 확인
        if self.backends["luma"].check_availability():
            print("📌 Luma API 사용")
            return self.backends["luma"]
        
        # 2. Kling API 확인
        if self.backends["kling"].check_availability():
            print("📌 Kling API 사용")
            return self.backends["kling"]
        
        # 3. 브라우저 모드 (기본)
        print("📌 브라우저 모드 사용 (Whisk)")
        return self.backends["browser"]
    
    def generate_video(self, request: VideoGenerationRequest) -> VideoGenerationResult:
        """영상 생성"""
        return self.active_backend.generate_video(request)
    
    def generate_all_scenes(self, script_path: str) -> List[VideoGenerationResult]:
        """스크립트의 모든 장면 처리"""
        
        with open(script_path, 'r', encoding='utf-8') as f:
            script = json.load(f)
        
        results = []
        scenes = script.get("scenes", [])
        
        print(f"\n🎬 총 {len(scenes)}개 장면 처리 시작")
        print("=" * 60)
        
        for i, scene in enumerate(scenes, 1):
            print(f"\n📌 장면 {i}/{len(scenes)}: {scene.get('title', 'Untitled')}")
            
            request = VideoGenerationRequest(
                scene_number=i,
                image_path=None,  # 이미지가 있으면 경로 지정
                image_prompt=scene.get("visual_prompt", ""),
                animation_prompt=scene.get("animation_prompt", "gentle movement"),
                duration_seconds=8
            )
            
            result = self.generate_video(request)
            results.append(result)
            
            if result.success:
                print(f"   ✓ 완료: {result.video_path}")
            else:
                print(f"   ✗ 실패: {result.error_message}")
        
        # 요약
        success_count = sum(1 for r in results if r.success)
        print("\n" + "=" * 60)
        print(f"✅ 완료: {success_count}/{len(results)} 장면")
        
        return results


# =============================================================================
# CLI 인터페이스
# =============================================================================

def main():
    """메인 실행"""
    import argparse
    
    parser = argparse.ArgumentParser(description="이미지→영상 변환")
    parser.add_argument("--mode", choices=["browser", "luma", "kling", "auto"],
                        default="auto", help="생성 모드")
    parser.add_argument("--scene", type=int, help="특정 장면 번호")
    parser.add_argument("--all", action="store_true", help="모든 장면 처리")
    parser.add_argument("--script", default="/home/claude/anime-pipeline/scripts/sample_script.json")
    parser.add_argument("--output", default="/home/claude/anime-pipeline/scenes/clips")
    
    args = parser.parse_args()
    
    generator = UnifiedVideoGenerator(mode=args.mode, output_dir=args.output)
    
    if args.all:
        # 모든 장면 처리
        results = generator.generate_all_scenes(args.script)
        
    elif args.scene:
        # 특정 장면 처리
        with open(args.script, 'r', encoding='utf-8') as f:
            script = json.load(f)
        
        scenes = script.get("scenes", [])
        if args.scene <= len(scenes):
            scene = scenes[args.scene - 1]
            request = VideoGenerationRequest(
                scene_number=args.scene,
                image_path=None,
                image_prompt=scene.get("visual_prompt", ""),
                animation_prompt=scene.get("animation_prompt", "gentle movement")
            )
            result = generator.generate_video(request)
            print(f"\n결과: {result}")
        else:
            print(f"장면 {args.scene}이 없습니다 (총 {len(scenes)}개)")
    
    else:
        print("--scene [번호] 또는 --all 옵션을 지정하세요")
        print("\n현재 설정:")
        print(f"  모드: {args.mode}")
        print(f"  스크립트: {args.script}")
        print(f"  출력: {args.output}")


if __name__ == "__main__":
    main()
