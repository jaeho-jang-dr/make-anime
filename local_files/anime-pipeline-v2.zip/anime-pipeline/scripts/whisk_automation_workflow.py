#!/usr/bin/env python3
"""
=============================================================================
🌐 Claude in Chrome - Whisk 자동화 워크플로우
=============================================================================

이 파일은 Claude in Chrome 환경에서 실행할 브라우저 자동화 워크플로우입니다.
Claude가 이 지시사항을 읽고 브라우저 도구를 사용하여 Whisk를 조작합니다.

사용법:
    1. Claude in Chrome 환경에서 이 파일 내용을 Claude에게 전달
    2. Claude가 자동으로 브라우저를 조작하여 영상 생성
    3. 생성된 영상이 다운로드됨

또는 Claude에게 직접 요청:
    "anime-pipeline의 whisk_automation_workflow.py를 읽고 
     sample_script.json의 장면 1번 영상을 Whisk로 생성해줘"
"""

import json
from pathlib import Path


class WhiskAutomationWorkflow:
    """
    Claude in Chrome이 실행할 Whisk 자동화 워크플로우
    
    이 클래스의 메서드들은 Claude가 브라우저 도구로 실행할 
    단계별 지시사항을 생성합니다.
    """
    
    WHISK_URL = "https://labs.google/fx/tools/whisk"
    
    def __init__(self, project_dir: str = "/home/claude/anime-pipeline"):
        self.project_dir = Path(project_dir)
        self.script_path = self.project_dir / "scripts" / "sample_script.json"
        self.output_dir = self.project_dir / "scenes" / "clips"
        self.output_dir.mkdir(parents=True, exist_ok=True)
    
    def load_script(self) -> dict:
        """스크립트 로드"""
        with open(self.script_path, 'r', encoding='utf-8') as f:
            return json.load(f)
    
    def get_scene_data(self, scene_number: int) -> dict:
        """특정 장면 데이터 가져오기"""
        script = self.load_script()
        scenes = script.get("scenes", [])
        
        if scene_number <= len(scenes):
            return scenes[scene_number - 1]
        return None
    
    def generate_workflow_instructions(self, scene_number: int) -> str:
        """
        Claude in Chrome이 실행할 워크플로우 지시사항 생성
        
        이 텍스트를 Claude에게 전달하면 Claude가 브라우저를 조작합니다.
        """
        
        scene = self.get_scene_data(scene_number)
        if not scene:
            return f"Error: Scene {scene_number} not found"
        
        script = self.load_script()
        style = script.get("style", "anime style")
        
        # 캐릭터 정보 가져오기
        characters = scene.get("characters", [])
        char_names = ", ".join(characters) if characters else "character"
        
        workflow = f"""
╔══════════════════════════════════════════════════════════════════════════════╗
║  🎬 WHISK 자동화 워크플로우 - 장면 {scene_number}                                ║
╚══════════════════════════════════════════════════════════════════════════════╝

📋 장면 정보:
   제목: {scene.get('title', 'Untitled')}
   캐릭터: {char_names}
   
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🔧 Claude가 실행할 단계:

【STEP 1】 Whisk 페이지 접속
   - URL: {self.WHISK_URL}
   - navigate 도구 사용
   - 페이지 로딩 완료까지 3초 대기

【STEP 2】 Subject (캐릭터) 입력
   - "Subject" 영역 찾기
   - 텍스트 입력 또는 프롬프트 입력:
   
   ┌─────────────────────────────────────────────────────────────────────────┐
   │ {scene.get('visual_prompt', 'anime character')}                         │
   └─────────────────────────────────────────────────────────────────────────┘

【STEP 3】 Scene (배경) 입력  
   - "Scene" 영역 찾기
   - 배경 프롬프트 입력:
   
   ┌─────────────────────────────────────────────────────────────────────────┐
   │ {scene.get('setting', 'fantasy background')}, anime background          │
   └─────────────────────────────────────────────────────────────────────────┘

【STEP 4】 Style (스타일) 입력
   - "Style" 영역 찾기
   - 스타일 프롬프트 입력:
   
   ┌─────────────────────────────────────────────────────────────────────────┐
   │ {style}, high quality anime art                                         │
   └─────────────────────────────────────────────────────────────────────────┘

【STEP 5】 이미지 생성
   - "Create" 또는 "Generate" 버튼 클릭
   - 이미지 생성 완료까지 대기 (약 30-60초)
   - 생성된 이미지 확인

【STEP 6】 ANIMATE 모드 전환
   - 생성된 이미지에서 "ANIMATE" 버튼 찾아 클릭
   - 애니메이션 옵션 패널 열림 확인

【STEP 7】 애니메이션 프롬프트 입력
   - 모션 프롬프트 입력:
   
   ┌─────────────────────────────────────────────────────────────────────────┐
   │ {scene.get('animation_prompt', 'gentle movement, anime style motion')}  │
   └─────────────────────────────────────────────────────────────────────────┘

【STEP 8】 영상 생성
   - "Generate" 버튼 클릭
   - 영상 생성 완료까지 대기 (약 1-2분)

【STEP 9】 다운로드
   - 다운로드 버튼 클릭
   - 파일명: scene_{scene_number:03d}.mp4
   - 저장 위치: {self.output_dir}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

✅ 완료 확인:
   - 파일이 정상적으로 다운로드되었는지 확인
   - 다음 장면으로 진행하려면 "다음 장면" 요청

❌ 오류 발생 시:
   - 스크린샷 촬영
   - 오류 내용 보고
   - 재시도 또는 수동 개입 요청
"""
        return workflow
    
    def generate_batch_workflow(self, start_scene: int = 1, end_scene: int = None) -> str:
        """여러 장면을 연속으로 처리하는 워크플로우"""
        
        script = self.load_script()
        total_scenes = len(script.get("scenes", []))
        
        if end_scene is None:
            end_scene = total_scenes
        
        workflow = f"""
╔══════════════════════════════════════════════════════════════════════════════╗
║  🎬 WHISK 배치 자동화 - 장면 {start_scene} ~ {end_scene}                        ║
╚══════════════════════════════════════════════════════════════════════════════╝

📋 프로젝트: {script.get('title', 'AI Anime')}
📋 처리할 장면: {start_scene} ~ {end_scene} (총 {end_scene - start_scene + 1}개)
📋 예상 시간: 약 {(end_scene - start_scene + 1) * 3}분

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🔄 배치 처리 절차:

1. Whisk 접속: {self.WHISK_URL}
2. 각 장면에 대해:
   a. Subject/Scene/Style 입력
   b. 이미지 생성
   c. ANIMATE → 영상 생성
   d. 다운로드 (scene_XXX.mp4)
   e. 다음 장면으로 이동

3. 완료 후 결과 보고

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📝 장면별 데이터:

"""
        for i in range(start_scene, end_scene + 1):
            scene = self.get_scene_data(i)
            if scene:
                workflow += f"""
【장면 {i}】 {scene.get('title', 'Untitled')}
   Visual: {scene.get('visual_prompt', '')[:50]}...
   Motion: {scene.get('animation_prompt', '')}
"""
        
        workflow += """
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

⚠️ 주의사항:
   - Google Ultra 구독 필요 (월 100개 영상 제한)
   - 각 영상 생성 후 잠시 대기 (rate limit 방지)
   - 오류 발생 시 해당 장면 건너뛰고 계속 진행

🚀 시작하려면 "배치 시작" 또는 "장면 X부터 시작" 요청
"""
        return workflow


def create_claude_prompt_for_whisk(scene_number: int) -> str:
    """
    Claude에게 전달할 Whisk 자동화 프롬프트 생성
    
    이 함수의 출력을 Claude in Chrome에게 전달하면
    Claude가 브라우저를 조작하여 영상을 생성합니다.
    """
    
    workflow = WhiskAutomationWorkflow()
    instructions = workflow.generate_workflow_instructions(scene_number)
    
    prompt = f"""
다음 지시사항에 따라 Whisk에서 애니메이션 영상을 생성해주세요.

{instructions}

브라우저 도구를 사용하여 위 단계를 순서대로 실행하고,
각 단계 완료 후 진행 상황을 알려주세요.
"""
    return prompt


def main():
    """테스트 실행"""
    import argparse
    
    parser = argparse.ArgumentParser(description="Whisk 자동화 워크플로우")
    parser.add_argument("--scene", type=int, default=1, help="장면 번호")
    parser.add_argument("--batch", action="store_true", help="배치 모드")
    parser.add_argument("--start", type=int, default=1, help="시작 장면")
    parser.add_argument("--end", type=int, help="종료 장면")
    parser.add_argument("--prompt", action="store_true", help="Claude 프롬프트 출력")
    
    args = parser.parse_args()
    
    workflow = WhiskAutomationWorkflow()
    
    if args.prompt:
        # Claude에게 전달할 프롬프트 출력
        print(create_claude_prompt_for_whisk(args.scene))
    elif args.batch:
        # 배치 워크플로우 출력
        print(workflow.generate_batch_workflow(args.start, args.end))
    else:
        # 단일 장면 워크플로우 출력
        print(workflow.generate_workflow_instructions(args.scene))


if __name__ == "__main__":
    main()
